XML2Contacts for Firefox OS - v0.4

Copyright (c) 2014 Jean Luc Biellmann (contact@alsatux.com)

Restore contacts from the SD-Card. Backups should be made using Contact2XML webapp.

This program is still under developpement and has been tested on a Geeksphone Peak with Firefox 1.1.
